set_clock_latency -source -early -min -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -early -min -fall -0.5 [get_clocks {clk_i}]
set_clock_latency -source -early -max -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -early -max -fall 0.5 [get_clocks {clk_i}]
set_clock_latency -source -late -min -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -late -min -fall -0.5 [get_clocks {clk_i}]
set_clock_latency -source -late -max -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -late -max -fall 0.5 [get_clocks {clk_i}]
set_clock_latency -source -early -min -rise  -2.16868 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -min -fall  -2.67048 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -rise  -2.16868 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -fall  -1.67048 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -rise  -2.16868 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -fall  -2.67048 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -rise  -2.16868 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -fall  -1.67048 [get_ports {clk_i}] -clock clk_i 
