set_clock_latency -rise 1.32895  [get_clocks {clk_div}]
set_clock_latency -fall 1.31724  [get_clocks {clk_div}]
set_clock_latency -source -early -min -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -early -min -fall -0.08 [get_clocks {clk_i}]
set_clock_latency -source -early -max -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -early -max -fall 0.08 [get_clocks {clk_i}]
set_clock_latency -source -late -min -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -late -min -fall -0.08 [get_clocks {clk_i}]
set_clock_latency -source -late -max -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -late -max -fall 0.08 [get_clocks {clk_i}]
set_clock_latency -source -early -min -rise  -2.28854 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -min -fall  -2.32038 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -rise  -2.28854 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -fall  -2.16038 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -rise  -2.28854 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -fall  -2.32038 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -rise  -2.28854 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -fall  -2.16038 [get_ports {clk_i}] -clock clk_i 
