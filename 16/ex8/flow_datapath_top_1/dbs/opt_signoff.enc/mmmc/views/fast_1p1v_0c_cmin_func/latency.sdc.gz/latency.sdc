set_clock_latency -rise 0.379362  [get_clocks {clk_div}]
set_clock_latency -fall 0.381112  [get_clocks {clk_div}]
set_clock_latency -source -early -min -rise  -0.653712 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -min -fall  -0.644812 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -rise  -0.653712 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -fall  -0.644812 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -rise  -0.653712 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -fall  -0.644812 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -rise  -0.653712 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -fall  -0.644812 [get_ports {clk_i}] -clock clk_i 
