set_clock_latency -source -early -min -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -early -min -fall -0.5 [get_clocks {clk_i}]
set_clock_latency -source -early -max -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -early -max -fall 0.5 [get_clocks {clk_i}]
set_clock_latency -source -late -min -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -late -min -fall -0.5 [get_clocks {clk_i}]
set_clock_latency -source -late -max -rise 0 [get_clocks {clk_i}]
set_clock_latency -source -late -max -fall 0.5 [get_clocks {clk_i}]
set_clock_latency -source -early -min -rise  -0.136558 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -min -fall  -0.638695 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -rise  -0.136558 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -fall  0.361305 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -rise  -0.136558 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -fall  -0.638695 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -rise  -0.136558 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -fall  0.361305 [get_ports {clk_i}] -clock clk_i 
