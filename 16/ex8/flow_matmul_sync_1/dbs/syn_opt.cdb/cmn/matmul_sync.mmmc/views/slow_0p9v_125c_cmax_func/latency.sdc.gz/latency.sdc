set_units -capacitance 1000fF
set_units -time 1000ps
set_clock_latency -source -min -rise 0.0 [get_clocks clk_i]
set_clock_latency -source -min -fall -0.1 [get_clocks clk_i]
set_clock_latency -source -max -rise 0.0 [get_clocks clk_i]
set_clock_latency -source -max -fall 0.1 [get_clocks clk_i]
