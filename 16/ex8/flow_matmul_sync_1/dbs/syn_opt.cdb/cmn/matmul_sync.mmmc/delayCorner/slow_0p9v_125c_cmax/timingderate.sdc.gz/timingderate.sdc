set_timing_derate -delay_corner slow_0p9v_125c_cmax -early -clock -cell_delay 0.927  
set_timing_derate -delay_corner slow_0p9v_125c_cmax -late -data -cell_delay 1.079  
set_timing_derate -delay_corner slow_0p9v_125c_cmax -late -clock -cell_delay 1.03  
set_timing_derate -delay_corner slow_0p9v_125c_cmax -early -clock -net_delay -static 0.93  
set_timing_derate -delay_corner slow_0p9v_125c_cmax -late -net_delay -static 1.07  
set_timing_derate -delay_corner slow_0p9v_125c_cmax -early -clock -net_delay -dynamic 0.93  
set_timing_derate -delay_corner slow_0p9v_125c_cmax -late -net_delay -dynamic 1.07  
