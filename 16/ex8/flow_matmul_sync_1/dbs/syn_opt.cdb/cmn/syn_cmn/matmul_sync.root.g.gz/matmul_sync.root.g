######################################################################

# Created by Genus(TM) Synthesis Solution 23.15-s099_1 on Fri Nov 14 14:45:27 EET 2025

# This file contains the Genus script for design:matmul_sync

######################################################################

set_db -quiet information_level 9
set_db -quiet path {. mode:matmul_sync/slow_0p9v_125c_cmax_scan_shift / /libraries/* /libraries/library_domains/*/* /libraries/library_sets/*/* /libraries/library_domains/* /libraries/library_sets/* /designs/* /designs/*/timing/clocks/ /designs/*/timing/clock_domains/* /designs/*/dft/test_clock_domains/* /designs/*/dft/mbist/mbist_clock_domains/* /designs/*/modes /designs/*/modes/*/clocks /designs/*/modes/*/clock_domains/* /mmmc_designs_spec/* /designs/*/mmmc/*}
set_db -quiet aae_enabled 1
set_db -quiet hdl_unconnected_value none
set_db -quiet phys_use_bin_route_type false
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet phys_vias_for_routing { 3 11 21 31 41 51}
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {{7.606797822548819e-5 6.893867117474131e-5 8.319728527623506e-5} {7.606797822548819e-5 6.893867117474131e-5 8.319728527623506e-5} {no_value no_value no_value}}
set_db -quiet resistance_per_unit_length_mmmc {{0.7520989008845955 0.7550050645790766 0.7491927371901145} {0.7520989008845955 0.7550050645790766 0.7491927371901145} {no_value no_value no_value}}
set_db -quiet global_route_overflow_TR_V 0.040626646434159586
set_db -quiet lp_insert_clock_gating true
set_db -quiet lp_power_unit mW
set_db -quiet runtime_by_stage {{PBS_Generic-earlyCG 0 61 1.0 30.0} {to_generic 8 70 7 37} {first_condense 1 72 0 39} {PBS_Generic_Opt-Post 10 72 8.746770000000001 38.746769} {{PBS_Generic-Postgen HBO Optimizations} 0 72 0.0 38.746769} {PBS_Generic_Opt-Physical 11 83 2.8760499999999993 41.622819} {PBS_Generic_Opt-PAM_PAS 0 83 1.0 42.622819} {PBS_Generic-earlyCG_cleanup 0 84 0.0 42.622819} {PBS_TechMap-Start 0 37 0.0 21.0} {PBS_TechMap-PAM_PAS 0 37 0.0 21.0} {first_condense 2 40 1 23} {reify 17 57 28 51} {global_incr_map 5 62 5 57} {{PBS_Techmap-Global Mapping} 26 63 22.093329000000004 43.093329000000004} {{PBS_TechMap-Datapath Postmap Operations} 1 64 1.9816450000000003 45.074974000000005} {{PBS_TechMap-Postmap HBO Optimizations} 0 64 -0.015291999999995198 45.05968200000001} {{PBS_TechMap-Postmap Physical Flow} 0 64 0.0 45.05968200000001} {{PBS_TechMap-Postmap Clock Gating} 0 64 0.0 45.05968200000001} {{PBS_TechMap-Postmap Cleanup} 2 66 0.9786179999999973 46.03830000000001} {PBS_Techmap-Post_MBCI 1 67 0.0 46.03830000000001}}
set_db -quiet timing_analysis_clock_propagation_mode forced_ideal
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs false
set_db -quiet dft_optimize_chain_wirelength_level low
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet opt_spatial_effort_executed standard
set_db -quiet hdl_generate_index_style %s_%d
set_db -quiet hdl_generate_separator _
set_db -quiet hdl_instance_array_naming_style %s_%d
set_db -quiet hdl_bus_wire_naming_style %s_%d
set_db -quiet hdl_array_naming_style %s_%d
set_db -quiet hdl_record_naming_style %s_%s
set_db -quiet tinfo_tstamp_file .rs_student.tstamp
set_db -quiet invs_preload_script scripts/innovus_config.tcl
set_db -quiet invs_postload_script {}
set_db -quiet pam_cone_opt_zero_pa true
set_db -quiet pam_cone_opt_global_buffering false
set_db -quiet pam_cone_opt_skip_annotation true
set_db -quiet common_preserve_skip_internal true
set_db -quiet innovus_create_qrc_extraction_data true
set_db -quiet opt_pre_ispatial_dbt true
set_db -quiet last_stylus_db /tmp/genus_temp_5714_73e4fccb-8870-48a6-9ece-9d6351b0cf6a_ASIC-vm_student_G9AOhP/invs_temp_dir/invs2genus_final_db
set_db -quiet flow_template_type block
set_db -quiet flow_template_tools {}
set_db -quiet flow_template_version 1
set_db -quiet flow_template_feature_definition {flow_express {} report_schedule {} report_defer 0 report_none 0 report_clp {} report_lec {} dft_simple {} dft_compressor {} synth_hybrid 0 synth_spatial {} synth_physical {} opt_early_cts 1 opt_preroute 0 clock_design 0 clock_flexible_htree 0 opt_postcts_hold_disable {} opt_postcts_split 0 route_track_opt 0 route_secondary_nets {} opt_postroute_split {} opt_route 0 opt_signoff {} opt_em {} opt_eco {} sta_dmmmc 0 sta_glitch 0 sta_eco {} run_joules_power {} generate_models {} disable_naming_rules {} dont_use_ulvt {} add_mbist {} add_scan {} add_opcg {} add_bscan {} add_1500 {} run_atpg {} run_dft {} full_atpg {} add_pvs_fill {} add_pegasus_beol_fill {} add_pvs_feol_fill {} add_pegasus_feol_fill {} check_drc_pvs {} check_drc_pegasus {} check_lvs_pvs {} check_lvs_pegasus {} fix_route_drc {} pnr_db_handoff {} rail_analysis {}}
set_db -quiet flow_features {flow_express {feature flow_express required 0 takes_value 0 valid_values {} default 0 desc {Enable express synthesis and implementation flow}} report_schedule {feature report_schedule required 0 takes_value 0 valid_values {} default 0 desc {Run report generation as a separate thread (note uses additional license) vs inline}} report_clp {feature report_clp required 0 takes_value 0 valid_values {} default 0 desc {Add CLP dofile generation and checks to the flow}} report_lec {feature report_lec required 0 takes_value 0 valid_values {} default true desc {Add LEC dofile generation and checks to the flow}} dft_simple {feature dft_simple required 0 takes_value 0 valid_values {} default 0 desc {Add flow support for scan chain insertion}} dft_compressor {feature dft_compressor required 0 takes_value 0 valid_values {} default 0 desc {Add flow support for scan chains with compression insertion}} synth_spatial {feature synth_spatial required 0 takes_value 0 valid_values {} default true desc {Physically aware synthesis flow with spatial final optimization}} synth_physical {feature synth_physical required 0 takes_value 0 valid_values {} default 0 desc {Physically aware synthesis flow with full phgysical final optimization}} opt_postcts_hold_disable {feature opt_postcts_hold_disable required 0 takes_value 0 valid_values {} default 0 desc {Disable postcts hold fixing}} route_secondary_nets {feature route_secondary_nets required 0 takes_value 0 valid_values {} default 0 desc {Route secondary PG nets before route_design}} opt_postroute_split {feature opt_postroute_split required 0 takes_value 0 valid_values {} default 0 desc {Run postroute opt_design for setup and hold as separate steps}} opt_signoff {feature opt_signoff required 0 takes_value 0 valid_values {} default true desc {Run opt_signoff during implementation flow}} rail_analysis {feature rail_analysis required 0 takes_value 0 valid_values {} default 0 desc {Run rail analysis in Voltus after flow}} opt_em {feature opt_em required 0 takes_value 0 valid_values {} default 0 desc {Run EM (Electromigration) optimization during implementation flow}} opt_eco {feature opt_eco required 0 takes_value 0 valid_values {} default 0 desc {Run opt_design during eco flow}} sta_eco {feature sta_eco required 0 takes_value 0 valid_values {} default 0 desc {Run opt_signoff during signoff flow}} add_pvs_fill {feature add_pvs_fill required 0 takes_value 0 valid_values {} default 0 desc {Insert metal fill using PVS}} add_pegasus_beol_fill {feature add_pegasus_beol_fill required 0 takes_value 0 valid_values {} default 0 desc {Insert metal fill using PEGASUS}} add_pvs_feol_fill {feature add_pvs_feol_fill required 0 takes_value 0 valid_values {} default 0 desc {Insert FEOL fill using PVS}} add_pegasus_feol_fill {feature add_pegasus_feol_fill required 0 takes_value 0 valid_values {} default 0 desc {Insert FEOL fill using PEGASUS}}}
set_db -quiet flow_feature_values {flow_express 0 report_schedule 0 report_clp 0 report_lec true dft_simple 0 dft_compressor 0 synth_spatial true synth_physical 0 opt_postcts_hold_disable 0 route_secondary_nets 0 opt_postroute_split 0 opt_signoff true rail_analysis 0 opt_em 0 opt_eco 0 sta_eco 0 add_pvs_fill 0 add_pegasus_beol_fill 0 add_pvs_feol_fill 0 add_pegasus_feol_fill 0 pnr_db_handoff true add_scan true generate_models true}
set_db -quiet flow_plugin_steps {{before Cadence.plugin.flowkit.read_db.post flow_step:activate_views} {before Cadence.plugin.flowkit.read_db.pre flow_step:activate_views} {after Cadence.plugin.flowkit.read_db.pre flow_step:init_mcpu} {after Cadence.plugin.flowkit.read_db.post flow_step:init_mcpu}}
set_db -quiet flow_status_file flow.status.d/syn_opt
set_db -quiet flow_starting_db {rc dbs/syn_map.db matmul_sync {}}
set_db -quiet flow_top flow:block
set_db -quiet flow_metrics_file flow.metrics.d/syn_opt
set_db -quiet flow_caller_data {group 0 process_branch 0 trunk_process 1 flowtool_hostname ASIC-vm flowtool_pid 3079}
set_db -quiet flow_step_canonical_current {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:block_finish} step flow_step:block_finish features {} str syn_opt.block_finish}
set_db -quiet flow_step_current flow_step:block_finish
set_db -quiet flow_hier_path {flow:block flow:syn_opt}
set_db -quiet flow_header_tcl {
    #- Extend flow report name based on context
    if {[is_flow -quiet -inside flow:sta] || [is_flow -quiet -inside flow:sta_dmmmc] || [is_flow -quiet -inside flow:sta_eco]} {
	if {![regexp {sta$} [get_db flow_report_name]]} {
	    set_db flow_report_name [expr {[string is space [get_db flow_report_name]] ? "sta" : "[get_db flow_report_name].sta"}]
	}
    } elseif {[is_flow -quiet -inside flow:ir_early_static] || [is_flow -quiet -inside flow:ir_early_dynamic]} {
	if {![regexp {era$} [get_db flow_report_name]]} {
	    set_db flow_report_name [expr {[string is space [get_db flow_report_name]] ? "era" : "[get_db flow_report_name].era"}]
	}
    } elseif {[is_flow -quiet -inside flow:ir_grid] || [is_flow -quiet -inside flow:ir_static] || [is_flow -quiet -inside flow:ir_dynamic] || [is_flow -quiet -inside flow:ir_rampup]} {
	if {![regexp {ir$} [get_db flow_report_name]]} {
	    set_db flow_report_name [expr {[string is space [get_db flow_report_name]] ? "ir" : "[get_db flow_report_name].ir"}]
	}
    } elseif {[regexp {block_start|hier_start|eco_start} [get_db flow_step_current]]} {
	set_db flow_report_name [get_db [lindex [get_db flow_hier_path] end] .name]
    } else {
    }

    #- Create report directory (if necessary)
    file mkdir [file normalize [file join [get_db flow_report_directory] [get_db flow_report_name]]]
}
set_db -quiet flowtool_metrics_qor_html reports/qor.html
set_db -quiet flow_step_last_status success
set_db -quiet flow_history {{step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:block_start} step flow_step:block_start features {} str syn_generic.block_start} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:init_elaborate} step flow_step:init_elaborate features {} str syn_generic.init_elaborate} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:elaborate_design} step flow_step:elaborate_design features {} str syn_generic.elaborate_design} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:init_design} step flow_step:init_design features {} str syn_generic.init_design} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:init_genus} step flow_step:init_genus features {} str syn_generic.init_genus} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:manage_uncertainty} step flow_step:manage_uncertainty features {} str syn_generic.manage_uncertainty} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:set_dont_use} step flow_step:set_dont_use features {} str syn_generic.set_dont_use} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:set_dont_touch} step flow_step:set_dont_touch features {} str syn_generic.set_dont_touch} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:genus_manage_preserve} step flow_step:genus_manage_preserve features {} str syn_generic.genus_manage_preserve} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:genus_manage_derating} step flow_step:genus_manage_derating features {} str syn_generic.genus_manage_derating} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:genus_manage_ungrouping} step flow_step:genus_manage_ungrouping features {} str syn_generic.genus_manage_ungrouping} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:genus_uniquify_design} step flow_step:genus_uniquify_design features {} str syn_generic.genus_uniquify_design} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:edit_post_elaborate_netlist} step flow_step:edit_post_elaborate_netlist features {} str syn_generic.edit_post_elaborate_netlist} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:init_scan} step flow_step:init_scan features {} str syn_generic.init_scan} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:genus_add_dft_constraints} step flow_step:genus_add_dft_constraints features {} str syn_generic.genus_add_dft_constraints} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:create_cost_group} step flow_step:create_cost_group features {} str syn_generic.create_cost_group} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:generate_activity_file} step flow_step:generate_activity_file features {} str syn_generic.generate_activity_file} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:genus_read_activity_file} step flow_step:genus_read_activity_file features {} str syn_generic.genus_read_activity_file} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:pre_syn_generic} step flow_step:pre_syn_generic features {} str syn_generic.pre_syn_generic} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:run_syn_generic} step flow_step:run_syn_generic features {} str syn_generic.run_syn_generic} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_generic .steps flow_step:block_finish} step flow_step:block_finish features {} str syn_generic.block_finish} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_map .steps flow_step:block_start} step flow_step:block_start features {} str syn_map.block_start} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_map .steps flow_step:init_genus} step flow_step:init_genus features {} str syn_map.init_genus} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_map .steps flow_step:pre_syn_map} step flow_step:pre_syn_map features {} str syn_map.pre_syn_map} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_map .steps flow_step:run_syn_map} step flow_step:run_syn_map features {} str syn_map.run_syn_map} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_map .steps flow_step:block_finish} step flow_step:block_finish features {} str syn_map.block_finish} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.start_steps flow_step:activate_views} step flow_step:activate_views features {} str activate_views} status success msg {}} {step {tool genus flow {.name plugin .tool genus} canonical_path {.end_steps flow_step:init_mcpu} step flow_step:init_mcpu features {} str init_mcpu} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:block_start} step flow_step:block_start features {} str syn_opt.block_start} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:init_genus} step flow_step:init_genus features {} str syn_opt.init_genus} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:add_scan_logic} step flow_step:add_scan_logic features {} str syn_opt.add_scan_logic} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:genus_add_dft_constraints} step flow_step:genus_add_dft_constraints features {} str syn_opt.genus_add_dft_constraints} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:run_syn_opt} step flow_step:run_syn_opt features {} str syn_opt.run_syn_opt} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:genus_update_names} step flow_step:genus_update_names features {} str syn_opt.genus_update_names} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:load_additional_procedures} step flow_step:load_additional_procedures features {} str syn_opt.load_additional_procedures} status success msg {}} {step {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow_step:block_finish} step flow_step:block_finish features {} str syn_opt.block_finish} status success msg {}}}
set_db -quiet max_cpus_per_server 16
set_db -quiet use_scan_seqs_for_non_dft false
set_db -quiet ocv_mode true
set_db -quiet use_area_from_lef true
set_db -quiet number_of_routing_layers 7
set_db -quiet dft_prefix DFT_matmul_sync_
set_db -quiet dft_identify_test_signals false
set_db -quiet dft_identify_top_level_test_clocks false
set_db -quiet dft_auto_identify_shift_register true
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet hdl_max_loop_limit 32768
set_db -quiet hdl_parameterize_module_name false
set_db -quiet invs_temp_dir /tmp/genus_temp_5714_73e4fccb-8870-48a6-9ece-9d6351b0cf6a_ASIC-vm_student_G9AOhP/invs_temp_dir
set_db -quiet flow_step_last flow_step:block_finish
set_db -quiet flow_step_next {tool genus flow flow:block canonical_path {.steps flow:syn_opt .steps flow:report_synth .steps flow_step:report_start} step flow_step:report_start features {} str syn_opt.report_synth.report_start}
set_db -quiet flow_metrics_snapshot_uuid 159cbe96-8904-4505-a704-0fc12352cc72
set_db -quiet read_qrc_tech_file_rc_corner true
set_db -quiet load_libraries_of_inactive_views 2
set_db -quiet use_multi_clks_latency_uncertainty_report true
set_db -quiet use_multi_clks_latency_uncertainty_optimize true
set_db -quiet timing_analysis_clock_source_paths false
set_db -quiet opt_multi_bit_flop_opt false
set_db -quiet delaycal_enable_high_fanout true
set_db -quiet timing_report_retime_formatting_mode retime_replace
set_db -quiet flow_user_templates {}
set_db -quiet flow_remark {}
set_db -quiet flow_mail_to {}
set_db -quiet flow_source_directory /home/student/16/ex8/flow_matmul_sync_1/cadence_flow_scripts/scripts
set_db -quiet flow_include_files {genus_config.tcl innovus_config.tcl tempus_config.tcl modus_config.tcl dft_config.tcl em_config.tcl flow_existing_step_overwrite.tcl}
set_db -quiet flow_report_name syn_opt
set_db -quiet flow_vars_data_directory /home/student/16/ex8/flow_matmul_sync_1
set_db -quiet flow_vars_dft_data_directory /home/student/16/ex8/flow_matmul_sync_1/dft_lib
set_db -quiet flow_vars_dft_library /home/student/16/ex8/flow_matmul_sync_1/dft_lib/dft_lib_specify.v
set_db -quiet flow_vars_dft_ncsim_library /home/student/16/ex8/flow_matmul_sync_1/dft_lib/dft_lib_specify.v
set_db -quiet flow_vars_stdcell_path /opt/soc/tech/GPDK045/gsclib045
set_db -quiet flow_vars_qrc_tech_directory /opt/soc/tech/GPDK045/gsclib045/qrc
set_db -quiet flow_vars_lef_tech_file /opt/soc/tech/GPDK045/gsclib045/lef/gsclib045_tech.lef
set_db -quiet flow_vars_gdsout_stream_map_file /opt/soc/tech/GPDK045/gsclib045/oa22/gsclib045/gsclib045.layermap
set_db -quiet flow_vars_rtl_root_dir .
set_db -quiet flow_vars_design_name matmul_sync
set_db -quiet flow_vars_design_top matmul_sync
set_db -quiet flow_vars_power_intent /home/student/16/ex8/flow_matmul_sync_1/constraints/matmul_sync.upf
set_db -quiet flow_vars_floorplan_def /home/student/16/ex8/flow_matmul_sync_1/floorplan_def/matmul_sync.def.gz
set_db -quiet flow_vars_tcf_file {/userwork8/tlehtine/projects/ML/sim/mem_pow_test/sim_out_read_1GHz.vcd tb_top.i_dut}
set_db -quiet flow_vars_constraint_modes {func scan_capture scan_shift}
set_db -quiet flow_vars_setup_synth_active_views {slow_0p9v_125c_cmax_func slow_0p9v_125c_cmax_scan_capture slow_0p9v_125c_cmax_scan_shift}
set_db -quiet flow_vars_setup_pnr_active_views {slow_0p9v_125c_cmax_func slow_0p9v_125c_cmax_scan_capture slow_0p9v_125c_cmax_scan_shift}
set_db -quiet flow_vars_setup_sta_active_views {slow_0p9v_125c_cmax_func slow_0p9v_125c_cmax_scan_capture slow_0p9v_125c_cmax_scan_shift}
set_db -quiet flow_vars_hold_views fast_1p1v_0c_cmin_func
set_db -quiet flow_vars_hold_pnr_active_views {slow_0p9v_125c_cmax_func slow_0p9v_125c_cmax_scan_capture slow_0p9v_125c_cmax_scan_shift fast_1p1v_0c_cmin_func fast_1p1v_0c_cmin_scan_capture fast_1p1v_0c_cmin_scan_shift}
set_db -quiet flow_vars_hold_sta_active_views {slow_0p9v_125c_cmax_func slow_0p9v_125c_cmax_scan_capture slow_0p9v_125c_cmax_scan_shift fast_1p1v_0c_cmin_func fast_1p1v_0c_cmin_scan_capture fast_1p1v_0c_cmin_scan_shift}
set_db -quiet flow_vars_power_view slow_0p9v_125c_cmax_func
set_db -quiet flow_vars_lef_list {/opt/soc/tech/GPDK045/gsclib045/lef/gsclib045_tech.lef {} /opt/soc/tech/GPDK045/gsclib045/lef/gsclib045_macro.lef {}}
set_db -quiet flow_vars_stdcell_gds_list /opt/soc/tech/GPDK045/gsclib045/gds/gsclib045.gds
set_db -quiet flow_vars_dont_use_list {{{.name==*FOOFOO*}} {{.name==*FIIFAA*}}}
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
set_db -quiet design:matmul_sync .pi_commit_done true
