set_clock_latency -source -early -min -rise  -0.0524115 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -min -fall  -0.0550595 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -rise  -0.0524115 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -early -max -fall  -0.0550595 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -rise  -0.0524115 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -min -fall  -0.0550595 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -rise  -0.0524115 [get_ports {clk_i}] -clock clk_i 
set_clock_latency -source -late -max -fall  -0.0550595 [get_ports {clk_i}] -clock clk_i 
