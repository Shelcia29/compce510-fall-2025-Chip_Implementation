set_clock_latency 0  [get_ports {clk_i}] -clock [get_clocks {clk_i}]
