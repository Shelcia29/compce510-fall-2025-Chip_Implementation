set_timing_derate -delay_corner slow_0p9v_125c_cmax  -cell_delay -data -late   1.079 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -cell_delay -clock -early   0.927 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -cell_delay -clock -late   1.03 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -net_delay -static  -data -late   1.07 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -net_delay -static  -clock -early   0.93 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -net_delay -static  -clock -late   1.07 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -net_delay -dynamic -data -late   1.07 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -net_delay -dynamic -clock -early   0.93 
set_timing_derate -delay_corner slow_0p9v_125c_cmax  -net_delay -dynamic -clock -late   1.07 
